"""
app.py

Streamlit front-end for the RAG Document Question Answering system.
Workflow:
  1. User enters Cohere + Pinecone API keys in the sidebar
  2. User uploads a PDF
  3. User asks a question
  4. VectorStore retrieves relevant chunks, Chatbot generates a grounded answer
"""

import streamlit as st
from vectorstore import VectorStore
from chatbot import Chatbot


def main():
    st.set_page_config(page_title="Document QA Bot", page_icon="🤖")
    st.title("Document QA Bot 🤖")
    st.write("Upload a PDF, input your API keys, and ask questions grounded in that document.")

    if "chat_history" not in st.session_state:
        st.session_state["chat_history"] = []
    if "vectorstore" not in st.session_state:
        st.session_state["vectorstore"] = None
    if "chatbot" not in st.session_state:
        st.session_state["chatbot"] = None

    # ---------- Sidebar: API keys ----------
    with st.sidebar:
        st.header("API Keys 🔑")
        cohere_api_key = st.text_input("Cohere API Key", type="password")
        pinecone_api_key = st.text_input("Pinecone API Key", type="password")
        st.caption("Get a Cohere key at dashboard.cohere.com and a Pinecone key at app.pinecone.io")

    # ---------- Document upload ----------
    uploaded_file = st.file_uploader("Upload a PDF file", type="pdf")
    user_query = st.text_input("Ask a question based on the document")

    build_disabled = not (uploaded_file and cohere_api_key and pinecone_api_key)

    if st.button("Process document", disabled=build_disabled):
        with st.spinner("Reading PDF, chunking, embedding, and indexing..."):
            with open("uploaded_document.pdf", "wb") as f:
                f.write(uploaded_file.read())

            st.session_state["vectorstore"] = VectorStore(
                "uploaded_document.pdf", cohere_api_key, pinecone_api_key
            )
            st.session_state["chatbot"] = Chatbot(st.session_state["vectorstore"], cohere_api_key)

        vs = st.session_state["vectorstore"]
        extracted_chars = len(vs.pdf_text.strip())
        if extracted_chars < 50:
            st.error(
                f"Only extracted {extracted_chars} characters of text from this PDF. "
                "This usually means the PDF stores text as images or design elements "
                "(common in Canva/graphic-design resume templates) rather than real "
                "selectable text. Try a different PDF, or export/print it as a "
                "'plain text' PDF and re-upload."
            )
        else:
            st.success(f"Extracted {extracted_chars} characters, indexed {len(vs.chunks)} chunks. Ask away!")

    # ---------- Ask a question ----------
    if st.button("Ask", disabled=not user_query or st.session_state["chatbot"] is None):
        with st.spinner("Retrieving context and generating an answer..."):
            response, retrieved_docs = st.session_state["chatbot"].respond(user_query)

            accumulated_response = ""
            for event in response:
                if event.type == "content-delta":
                    accumulated_response += event.delta.message.content.text

            st.session_state["chatbot"].record_assistant_turn(accumulated_response)
            st.session_state["chat_history"].append((user_query, accumulated_response, retrieved_docs))

    # ---------- Chat history ----------
    if st.session_state["chat_history"]:
        st.divider()
        for q, a, docs in reversed(st.session_state["chat_history"]):
            st.markdown(f"**You:** {q}")
            st.markdown(f"**Bot:** {a}")
            if docs:
                with st.expander("Sources used"):
                    for i, d in enumerate(docs, 1):
                        st.markdown(f"**Chunk {i}:** {d.get('text', '')[:400]}...")


if __name__ == "__main__":
    main()
