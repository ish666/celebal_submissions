"""
chatbot.py

Handles the "augmentation" and "generation" halves of the RAG pipeline using
Cohere's Chat V2 API:
  1. Pull relevant chunks from the VectorStore for the user's message
  2. Feed those chunks to Cohere's chat model as grounding documents
  3. Stream back a generated answer

Note: Cohere retired the v1 Chat API's `search_queries_only` / `conversation_id`
parameters (Sept 2025). This version always retrieves context for each message
and manages conversation history itself via the `messages` list, per the
current Chat V2 API.
"""

import cohere


class Chatbot:
    def __init__(self, vectorstore, cohere_api_key: str, model: str = "command-r-08-2024"):
        self.vectorstore = vectorstore
        self.co = cohere.ClientV2(cohere_api_key)
        self.model = model
        self.messages = [
            {
                "role": "system",
                "content": "You are a helpful assistant that answers questions "
                            "using only the provided document context. If the "
                            "context doesn't contain the answer, say so.",
            }
        ]

    def respond(self, user_message: str):
        # ---------- Context Retrieval ----------
        retrieved_docs = self.vectorstore.retrieve(user_message)
        documents = [{"data": {"text": d.get("text", "")}} for d in retrieved_docs] or None

        self.messages.append({"role": "user", "content": user_message})

        # ---------- Answer Generation (grounded) ----------
        response = self.co.chat_stream(
            model=self.model,
            messages=self.messages,
            documents=documents,
        )

        return response, retrieved_docs

    def record_assistant_turn(self, full_text: str):
        """Call this after streaming completes, to keep multi-turn context."""
        self.messages.append({"role": "assistant", "content": full_text})
