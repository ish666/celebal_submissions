# Document Question Answering System (RAG)

A Retrieval-Augmented Generation system that answers questions grounded in your own PDFs, using **Cohere** for embeddings/generation/reranking and **Pinecone** as the vector database.

## Architecture

```
PDF ─▶ Text Extraction ─▶ Chunking ─▶ Embedding (Cohere) ─▶ Pinecone Index
                                                                   │
User Question ─▶ Query Embedding ─▶ Retrieve top-k ─▶ Rerank ─────┘
                                                                   │
                                          Retrieved Chunks ─▶ Cohere Chat (grounded generation) ─▶ Answer
```

| Stage | Component | File |
|---|---|---|
| Document ingestion | PyMuPDF (`fitz`) | `vectorstore.py` |
| Text chunking | Sentence-based splitter | `vectorstore.py` |
| Embedding creation | Cohere `embed-english-v3.0` | `vectorstore.py` |
| Vector database | Pinecone serverless index | `vectorstore.py` |
| Retrieval + rerank | Cohere `rerank-english-v2.0` | `vectorstore.py` |
| Answer generation | Cohere `command-r` | `chatbot.py` |
| UI | Streamlit | `app.py` |

## Setup

1. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

2. **Get API keys**
   - Cohere: https://dashboard.cohere.com/api-keys
   - Pinecone: https://app.pinecone.io

   Either paste them into the app's sidebar at runtime, or copy `.env.example` to `.env` and fill them in if you wire up `python-dotenv` yourself.

3. **Run the app**
   ```bash
   streamlit run app.py
   ```

4. **Use it**
   - Enter your Cohere and Pinecone keys in the sidebar
   - Upload a PDF (notes, resume, research paper, book, etc.)
   - Click **Process document** — this chunks, embeds, and indexes it
   - Type a question and click **Ask**

## Notes on the reference implementation

This closely follows the reference `rag.docx` code, with a couple of fixes/cleanups:
- Fixed a bug where `index_chunks` referenced an undefined `self.docs_embs` instead of `self.embeddings` when computing the index dimension.
- Split monolithic script into cleanly separated `VectorStore`, `Chatbot`, and `app.py` modules (mirrors the original files, just organized as a proper package).
- Added guards for empty retrieval results, an `index_name`/`top_k` constructor knobs, and slightly more informative Streamlit UI (spinners, source-chunk preview, indexed-chunk count).

## Possible improvements (from the project brief)

- Better chunking strategies (semantic/recursive chunking instead of naive sentence splitting)
- Try different embedding models
- Hybrid search (keyword + vector)
- Additional re-ranking tuning
- Experiment with different generation models
