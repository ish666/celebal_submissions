"""
vectorstore.py

Handles the "retrieval" half of the RAG pipeline:
  1. Load a PDF and extract raw text
  2. Split the text into overlapping chunks
  3. Embed each chunk with Cohere
  4. Store/index the embeddings in Pinecone
  5. Retrieve + rerank the most relevant chunks for a given query
"""

import cohere
import fitz  # PyMuPDF
from pinecone import Pinecone, ServerlessSpec


class VectorStore:
    def __init__(self, pdf_path: str, cohere_api_key: str, pinecone_api_key: str,
                 index_name: str = "rag-qa-bot", retrieve_top_k: int = 10, rerank_top_k: int = 3):
        self.pdf_path = pdf_path
        self.co = cohere.Client(cohere_api_key)
        self.pinecone_api_key = pinecone_api_key
        self.index_name = index_name
        self.retrieve_top_k = retrieve_top_k
        self.rerank_top_k = rerank_top_k

        self.chunks = []
        self.embeddings = []

        # Build the pipeline end-to-end on init
        self.pdf_text = self._extract_text_from_pdf(self.pdf_path)
        self._split_text()
        self._embed_chunks()
        self._index_chunks()

    # ---------- Document Ingestion ----------
    def _extract_text_from_pdf(self, pdf_path: str) -> str:
        text = ""
        with fitz.open(pdf_path) as pdf:
            for page_num in range(pdf.page_count):
                page = pdf.load_page(page_num)
                text += page.get_text("text")
        return text

    # ---------- Text Chunking ----------
    def _split_text(self, chunk_size: int = 1000):
        """Naive sentence-based chunking, capped at chunk_size characters."""
        sentences = self.pdf_text.split(". ")
        current_chunk = ""
        for sentence in sentences:
            if len(current_chunk) + len(sentence) < chunk_size:
                current_chunk += sentence + ". "
            else:
                self.chunks.append(current_chunk.strip())
                current_chunk = sentence + ". "
        if current_chunk.strip():
            self.chunks.append(current_chunk.strip())

    # ---------- Embedding Creation ----------
    def _embed_chunks(self, batch_size: int = 90):
        total_chunks = len(self.chunks)
        for i in range(0, total_chunks, batch_size):
            batch = self.chunks[i:min(i + batch_size, total_chunks)]
            batch_embeddings = self.co.embed(
                texts=batch,
                input_type="search_document",
                model="embed-english-v3.0",
            ).embeddings
            self.embeddings.extend(batch_embeddings)

    # ---------- Vector Database ----------
    def _index_chunks(self):
        pc = Pinecone(api_key=self.pinecone_api_key)

        if self.index_name not in pc.list_indexes().names():
            pc.create_index(
                name=self.index_name,
                dimension=len(self.embeddings[0]),
                metric="cosine",
                spec=ServerlessSpec(cloud="aws", region="us-east-1"),
            )
        self.index = pc.Index(self.index_name)

        chunks_metadata = [{"text": chunk} for chunk in self.chunks]
        ids = [str(i) for i in range(len(self.chunks))]
        self.index.upsert(vectors=zip(ids, self.embeddings, chunks_metadata))

    # ---------- Query Processing + Context Retrieval ----------
    def retrieve(self, query: str) -> list:
        query_emb = self.co.embed(
            texts=[query],
            model="embed-english-v3.0",
            input_type="search_query",
        ).embeddings[0]  # embed() always returns a list of vectors; take the single query's vector

        res = self.index.query(
            vector=query_emb,
            top_k=self.retrieve_top_k,
            include_metadata=True,
        )

        docs_to_rerank = [match["metadata"]["text"] for match in res["matches"]]
        if not docs_to_rerank:
            return []

        rerank_results = self.co.rerank(
            query=query,
            documents=docs_to_rerank,
            top_n=min(self.rerank_top_k, len(docs_to_rerank)),
            model="rerank-v3.5",
        )
        return [res["matches"][result.index]["metadata"] for result in rerank_results.results]
